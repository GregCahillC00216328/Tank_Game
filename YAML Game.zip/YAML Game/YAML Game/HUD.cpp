#include "HUD.h"


////////////////////////////////////////////////////////////
HUD::HUD(sf::Font & hudFont)
	: m_textFont(hudFont)
{
	m_gameStateText.setFont(hudFont);
	m_gameStateText.setCharacterSize(30);
	m_gameStateText.setFillColor(sf::Color::Blue);
	m_gameStateText.setPosition(sf::Vector2f(180, 5));
	m_gameStateText.setString("Game Running");

	m_playerHealth.setFont(hudFont);
	m_playerHealth.setCharacterSize(30);
	m_playerHealth.setOutlineThickness(1);
	m_playerHealth.setOutlineColor(sf::Color::Black);
	m_playerHealth.setFillColor(sf::Color::White);
	m_playerHealth.setPosition(sf::Vector2f(480, 5));


	m_enemyHealth.setFont(hudFont);
	m_enemyHealth.setCharacterSize(30);
	m_enemyHealth.setOutlineThickness(1);
	m_enemyHealth.setOutlineColor(sf::Color::Black);
	m_enemyHealth.setFillColor(sf::Color::White);
	m_enemyHealth.setPosition(sf::Vector2f(780, 5));


	//Setting up our hud properties 
	m_hudOutline[0].setSize(sf::Vector2f(1440.0f, 40.0f));
	m_hudOutline[0].setFillColor(sf::Color(0, 0, 0, 38));
	m_hudOutline[0].setOutlineThickness(-.5f);
	m_hudOutline[0].setOutlineColor(sf::Color(0, 0, 0, 100));
	m_hudOutline[0].setPosition(0, 0);

	m_hudOutline[1].setSize(sf::Vector2f(40.0f, 40.0f));
	m_hudOutline[1].setOutlineThickness(1);
	m_hudOutline[1].setOutlineColor(sf::Color::Black);
	m_hudOutline[1].setFillColor(sf::Color(0, 0, 0, 38));
	m_hudOutline[1].setOutlineThickness(-.5f);
	m_hudOutline[1].setOutlineColor(sf::Color(0, 0, 0, 100));


	m_hudOutline[2].setSize(sf::Vector2f(40.0f, 40.0f));
	m_hudOutline[2].setFillColor(sf::Color(0, 0, 0, 38));
	m_hudOutline[2].setOutlineThickness(-.5f);
	m_hudOutline[2].setOutlineColor(sf::Color(0, 0, 0, 100));
}

////////////////////////////////////////////////////////////
void HUD::update(GameState const & gameState, Tank&t_tank, TankAi &t_tankai)
{
	switch (gameState)
	{
	case GameState::GAME_RUNNING:
		m_gameStateText.setString("Game Running");
		m_hudOutline[1].setPosition(t_tank.getBase().getPosition().x - 20,
			t_tank.getBase().getPosition().y - 80);
		m_hudOutline[2].setPosition(t_tankai.getSprites().getPosition().x - 20,
			t_tankai.getSprites().getPosition().y - 80);
		m_playerHealth.setString(std::to_string(t_tank.getHealth()));
		m_enemyHealth.setString(std::to_string(t_tankai.getHealth()));
		m_playerHealth.setPosition(t_tank.getBase().getPosition().x - 20,
			t_tank.getBase().getPosition().y - 80);
		m_enemyHealth.setPosition(t_tankai.getSprites().getPosition().x - 20,
			t_tankai.getSprites().getPosition().y - 80);
		break;
	case GameState::GAME_WIN:
		m_gameStateText.setString("You Won");
		break;
	case GameState::GAME_LOSE:
		m_gameStateText.setString("You Lost");
		break;
	default:
		break;
	}
}

void HUD::render(sf::RenderWindow & window)
{
	for (int i = 0; i < 3; i++)
	{
		window.draw(m_hudOutline[i]);
	}
	window.draw(m_playerHealth);
	window.draw(m_enemyHealth);
	window.draw(m_gameStateText);
}