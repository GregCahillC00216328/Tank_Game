
#ifndef GAME
#define GAME

#include <SFML/Graphics.hpp>
#include "LevelLoader.h"
#include "Tank.h"
#include "TankAI.h"
#include "GameState.h"
#include "HUD.h"


class Game
{
public:
	Game();
	~Game();
	/// <summary>
	/// main method for game
	/// </summary>
	void run();
	void reset();

private:

	void processEvents();
	void update(sf::Time t_deltaTime);
	void render();
	
	void setupFontAndText();
	void setupSprite();
	
	/// <summary>
	/// @brief Creates the wall sprites and loads them into a vector.
	/// Note that sf::Sprite is considered a light weight class, so 
	///  storing copies (instead of pointers to sf::Sprite) in std::vector is acceptable.
	/// </summary>
	void generateWalls();

	sf::Vector2f tankPos;
	sf::RenderWindow m_window; // main SFML window
	sf::Font m_ArialBlackfont; // font used by message
	sf::Text m_welcomeMessage; // text used for message on screen
	sf::Texture m_bgTexture; // texture used for background
	sf::Sprite m_bgSprite; // sprite used for background
	sf::Texture m_Texture;
	sf::Sprite m_sprite;
	bool m_exitGame; // control exiting game
	LevelData m_level;
	std::vector<sf::Sprite>  m_sprites;
	std::vector<sf::Sprite *> myVector;
	sf::Sprite sprite;
	Tank m_tank;
	KeyHandler m_keyHandler;
	std::vector<sf::Sprite> m_wallSprites;
	TankAi m_aiTank;
	GameState m_gameState{ GameState::GAME_RUNNING };
	sf::Texture healthPackTexture;
	sf::Sprite healthPackSprite;

	//The font used
	sf::Font m_font;

	//The Instance of HUD
	HUD m_hud;

	//TO keep track of restart
	float m_currentTime;
	float m_gameRunTime;

	bool m_aiTankHit = false;
	bool m_tankHit = false;
	int healthTimerSpawn = 20;
	int healthTimerDespawn = 5000;
	bool healthOnScreen = false;
	int maxDistanceFromHealth=250;
	sf::Text currentAITankState;
};


#endif // !GAME

