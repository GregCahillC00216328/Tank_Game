
#include "Game.h"
#include <iostream>
#include "CollisionDetector.h"
#include <stdlib.h>    
#include <time.h>      




Game::Game() :
	m_window{ sf::VideoMode{ 1440, 900, 32 }, "SFML Game" },
	m_exitGame{ false }, //when true game will exit
	m_tank(m_Texture, m_wallSprites, m_keyHandler),
	m_aiTank(m_Texture, m_wallSprites),
	m_hud(m_font)
{
	setupFontAndText(); // load font 
	setupSprite(); // load texture
	//EXERCISE 1
	int currentLevel = 1;
	if (!LevelLoader::load(currentLevel, m_level))
	{
		return;
	}
	m_window.setVerticalSyncEnabled(true);
	//EXERCISE 3
	if (!m_Texture.loadFromFile("./resources/images/SpriteSheet.png"))
	{
		std::string s("Error loading texture");
		throw std::exception(s.c_str());
	}
	
	m_tank.initSprites(m_level.m_tank.m_position);
	generateWalls();
	m_aiTank.init(m_level.m_aiTank.m_position);
}


Game::~Game()
{
}


void Game::run()
{
	sf::Clock clock;
	sf::Time timeSinceLastUpdate = sf::Time::Zero;
	sf::Time timePerFrame = sf::seconds(1.f / 60.f); // 60 fps
	while (m_window.isOpen())
	{
		
		processEvents(); // as many as possible
		timeSinceLastUpdate += clock.restart();
		while (timeSinceLastUpdate > timePerFrame)
		{
			timeSinceLastUpdate -= timePerFrame;
			processEvents(); // at least 60 fps
			update(timePerFrame); //60 fps
		}
		render(); // as many as possible
	}
}
void Game::reset()

	{
		setupFontAndText(); // load font 
		setupSprite(); // load texture
					   //EXERCISE 1
		int currentLevel = 1;
		if (!LevelLoader::load(currentLevel, m_level))
		{
			return;
		}
		m_window.setVerticalSyncEnabled(true);
		//EXERCISE 3
		if (!m_Texture.loadFromFile("./resources/images/SpriteSheet.png"))
		{
			std::string s("Error loading texture");
			throw std::exception(s.c_str());
		}
		m_tank.resetSpeed();
		m_tank.initSprites(m_level.m_tank.m_position);
		generateWalls();
		m_aiTank.init(m_level.m_aiTank.m_position);
		m_gameState = GameState::GAME_RUNNING;
	}
/// <summary>
/// handle user and system events/ input
/// get key presses/ mouse moves etc. from OS
/// and user :: Don't do game update here
/// </summary>
void Game::processEvents()
{
	//Lab 4 Exericse 1
	sf::Event event;
	



	
	while (m_window.pollEvent(event))
	{
		if ( sf::Event::Closed == event.type) // window message
		{
			m_window.close();
		}
		switch (event.type)
		{
		case sf::Event::KeyPressed:
			m_keyHandler.updateKey(event.key.code, true);
			break;
		case sf::Event::KeyReleased:
			m_keyHandler.updateKey(event.key.code, false);
			break;
		default:
			break;
		}
		if (sf::Event::KeyPressed == event.type) //user key press
		{
			if (sf::Keyboard::Escape == event.key.code)
			{
				m_exitGame = true;
			}
		
		}
	}
}

/// <summary>
/// Update the game world
/// </summary>
/// <param name="t_deltaTime">time interval per frame</param>
void Game::update(sf::Time t_deltaTime)
{
	srand(time(NULL));
	if (m_exitGame)
	{
		m_window.close();
	}
	m_currentTime += t_deltaTime.asMilliseconds();
	if (m_currentTime > 200 && m_gameState ==GameState::GAME_RUNNING)
	{
		m_currentTime = 0;
	}
	switch (m_gameState)
	{
	case GameState::GAME_RUNNING:

		m_tank.update(t_deltaTime.asMilliseconds(), m_aiTank.getSprites(), m_aiTankHit);
		m_aiTank.update(m_tank, t_deltaTime.asMilliseconds(), m_aiTankHit);
		m_gameRunTime += t_deltaTime.asMilliseconds();
		if (m_gameRunTime > 200)
		{
			m_gameRunTime = 0;
		}
		if (!healthOnScreen)
		{
			healthTimerDespawn = 300;
			healthTimerSpawn -= 1;
		}
		
		if (healthTimerSpawn <= 0 && !healthOnScreen)
		{
			healthTimerSpawn = 200;
			healthPackSprite.setPosition(rand() % 1440 + 1, rand() % 900 + 1);
			
			for (sf::Sprite &m_sprites : m_wallSprites)
			{
				while (CollisionDetector::collision(healthPackSprite, m_tank.getBase()) ||
					CollisionDetector::collision(healthPackSprite, m_aiTank.getSprites()) ||
					CollisionDetector::collision(healthPackSprite, m_sprites))
				{
					healthPackSprite.setPosition(rand() % 1440 + 1, rand() % 900 + 1);
				}
			}
			healthOnScreen = true;

		}
		if (healthOnScreen)
		{
			healthTimerSpawn = 200;
			healthTimerDespawn -= 1;
		}
		if (healthOnScreen && healthTimerDespawn <= 0)
		{
			healthTimerDespawn = 300;
			healthPackSprite.setPosition(-50,-50);
			healthOnScreen = false;
		}
		for (int i = 0; i < m_aiTank.getNextBullet(); i++)
		{
			if (CollisionDetector::collision(m_tank.getBase(), m_aiTank.getBulletSprite(i)))
			{
				m_tank.takeDamge();
				m_aiTank.setNextBullet(0,i);
				
			}
		}
		if (CollisionDetector::collision(m_tank.getBase(), healthPackSprite)&&healthOnScreen)
		{
			m_tank.heal();
			healthOnScreen = false;
			
		}
		if (CollisionDetector::collision(m_aiTank.getSprites(), healthPackSprite) && healthOnScreen)
		{
			m_aiTank.heal();
			healthOnScreen = false;
			healthTimerDespawn = 300;
			healthTimerSpawn = 200;

		}
		break;
		
		
	case GameState::GAME_LOSE:
		if (m_currentTime >m_gameRunTime*15)
		{
			reset();
		}
		break;
	case GameState::GAME_WIN:
		
		break;
	}
	m_hud.update(m_gameState,m_tank,m_aiTank);
	if (m_aiTank.getHealth() <=0)
	{
		m_gameState = GameState::GAME_WIN;
	}
	if (m_aiTank.collidesWithPlayer(m_tank))
	{
		m_gameState = GameState::GAME_LOSE;
	}
	
}

/// <summary>
/// draw the frame and then switch bufers
/// </summary>
void Game::render()
{
	sf::Vector2f nearHealth = healthPackSprite.getPosition() - m_tank.getBase().getPosition();
	m_window.clear(sf::Color::White);
	//EXERCISE 5
	m_window.draw(m_bgSprite);
	for (sf::Sprite &m_sprites : m_wallSprites)
	{
		m_window.draw(m_sprites);
	}
	m_tank.render(m_window);
	m_aiTank.render(m_window);
	m_hud.render(m_window);
	if (healthOnScreen &&
		nearHealth.x < maxDistanceFromHealth
		&& nearHealth.y < maxDistanceFromHealth
		&&nearHealth.x > -maxDistanceFromHealth
		&&nearHealth.y > -maxDistanceFromHealth)
	{
		m_window.draw(healthPackSprite);
	}
	
	m_window.display();
}

/// <summary>
/// load the font and setup the text message for screen
/// </summary>
void Game::setupFontAndText()
{
	if (!m_font.loadFromFile("./resources/fonts/ariblk.ttf"))
	{
		std::string s("Error loading font");
		throw std::exception(s.c_str());
	}

}

/// <summary>
/// load the texture and setup the sprite for the logo
/// </summary>
void Game::setupSprite()
{
	if (!m_bgTexture.loadFromFile("resources/images/Background.jpg"))
	{
		// simple error message if previous call fails
		std::cout << "problem loading logo" << std::endl;
	}
	m_bgSprite.setTexture(m_bgTexture);
	m_bgSprite.setPosition(0.0f, 0.0f);
	if (!healthPackTexture.loadFromFile("resources/images/health.png"))
	{
		// simple error message if previous call fails
		std::cout << "problem loading logo" << std::endl;
	}
	healthPackSprite .setTexture(healthPackTexture);
	healthPackSprite.setPosition(300.0f, 300.0f);
	healthPackSprite.setScale(.2,.2);
	
}



void Game::generateWalls()
{
	sf::IntRect wallRect(2, 129, 33, 23);
	// Create the Walls 
	for (ObstacleData const & obstacle : m_level.m_obstacles)
	{
		sf::Sprite sprite;
		sprite.setTexture(m_Texture);
		sprite.setTextureRect(wallRect);
		sprite.setOrigin(wallRect.width / 2.0, wallRect.height / 2.0);
		sprite.setPosition(obstacle.m_position);
		sprite.setRotation(obstacle.m_rotation);
		m_wallSprites.push_back(sprite);
	}
}


