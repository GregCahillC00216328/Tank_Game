#include "TankAi.h"

////////////////////////////////////////////////////////////
TankAi::TankAi(sf::Texture const & texture, std::vector<sf::Sprite> & wallSprites)
	: m_aiBehaviour(AiBehaviour::SEEK_PLAYER)
	, m_texture(texture)
	, m_wallSprites(wallSprites)
	, m_steering(0, 0)
{
	// Initialises the tank base and turret sprites.
	initSprites();
}

////////////////////////////////////////////////////////////
void TankAi::update(Tank const & playerTank, double dt, bool &aiTankHit, sf::Sprite &health,bool &healthOnScreen)
{
	

	if (m_health <= 5 && healthOnScreen)
	{
		m_aiBehaviour = AiBehaviour::FIND_HEALTH;
	}
	else if (m_health <= 5 && !healthOnScreen)
	{
		m_aiBehaviour = AiBehaviour::FIND_COVER;
	}
	else
	{
		m_aiBehaviour = AiBehaviour::SEEK_PLAYER;
	}
	sf::Vector2f vectorToPlayer;

	if (aiTankHit)
	{
		aiTankHit = false;
		takeDamge();
	}
	switch (m_aiBehaviour)
	{
	case AiBehaviour::SEEK_PLAYER:
		vectorToPlayer = seek(playerTank.getPosition());
		m_steering += thor::unitVector(vectorToPlayer);
		m_steering += collisionAvoidance();
		m_steering = MathUtility::truncate(m_steering, MAX_FORCE);
		m_velocity = MathUtility::truncate(m_velocity + m_steering, MAX_SPEED);
		m_currentStateText.setString("SEEK_PLAYER");
		break;
	case AiBehaviour::FIND_HEALTH:
		vectorToPlayer = seek(health.getPosition());
		m_steering += thor::unitVector(vectorToPlayer);
		m_steering += collisionAvoidance();
		m_steering = MathUtility::truncate(m_steering, MAX_FORCE);
		m_velocity = MathUtility::truncate(m_velocity + m_steering, MAX_SPEED*2);
		m_currentStateText.setString("FIND_HEALTH");
		
		break;
	case AiBehaviour::FIND_COVER:
		vectorToPlayer = -seek(playerTank.getPosition());
		m_steering += thor::unitVector(vectorToPlayer);
		m_steering += collisionAvoidance();
		m_steering = MathUtility::truncate(m_steering, MAX_FORCE);
		m_velocity = MathUtility::truncate(m_velocity + m_steering, MAX_SPEED*2);
		m_currentStateText.setString("FIND_COVER");
		break;
	default:
		break;
	}

	// Now we need to convert our velocity vector into a rotation angle between 0 and 359 degrees.
	// The m_velocity vector works like this: vector(1,0) is 0 degrees, while vector(0, 1) is 90 degrees.
	// So for example, 223 degrees would be a clockwise offset from 0 degrees (i.e. along x axis).
	// Note: we add 180 degrees below to convert the final angle into a range 0 to 359 instead of -PI to +PI
	auto dest = atan2(-1 * m_velocity.y, -1 * m_velocity.x) / thor::Pi * 180 + 180;

	auto currentRotation = m_rotation;
	if (vectorToPlayer.x < stopDistanceFromPlayer
		&& vectorToPlayer.y < stopDistanceFromPlayer
		&&vectorToPlayer.x > -stopDistanceFromPlayer
		&&vectorToPlayer.y > -stopDistanceFromPlayer && m_aiBehaviour==AiBehaviour::SEEK_PLAYER)
	{
		//m_velocity = sf::Vector2f(0, 0);
		stopAndRotate = true;
	}
	else {
		stopAndRotate = false;
	}
	// Find the shortest way to rotate towards the player (clockwise or anti-clockwise)
	if (std::round(currentRotation - dest) == 0.0)
	{
		m_steering.x = 0;
		m_steering.y = 0;
	}

	else if ((static_cast<int>(std::round(dest - currentRotation + 360))) % 360 < 180)
	{
		// rotate clockwise
		m_rotation = static_cast<int>((m_rotation)+1) % 360;
	}
	else
	{
		// rotate anti-clockwise
		m_rotation = static_cast<int>((m_rotation)-1) % 360;
	}

	//*UNCOMMENTING MAKES THE TANK NOT MOVE


	/*if (thor::length(vectorToPlayer) < MAX_SEE_AHEAD)
	{
		m_aiBehaviour = AiBehaviour::STOP;
	}
	else
	{
		m_aiBehaviour = AiBehaviour::RETREAT;
	}
*/
	updateMovement(dt);
	m_pool.update(dt, m_wallSprites, m_tankBase, aiTankHit);
	requestFire();
	if (m_shootTimer != 0)
	{
		m_shootTimer -= dt;
		if (m_shootTimer <= 0)
		{
			m_shootTimer = s_TIME_BETWEEN_SHOTS;
			m_fireRequested = false;
		}
	}
	
}

////////////////////////////////////////////////////////////
void TankAi::render(sf::RenderWindow & window)
{
	// TODO: Don't draw if off-screen...
	window.draw(m_tankBase);
	m_pool.render(window);
	window.draw(m_turret);
}

////////////////////////////////////////////////////////////
void TankAi::init(sf::Vector2f position)
{
	m_aiBehaviour = AiBehaviour::SEEK_PLAYER;
	m_currentStateText.setString("");
	m_tankBase.setPosition(position);
	m_turret.setPosition(position);
	m_health = 10;
	for (sf::Sprite const wallSprite : m_wallSprites)
	{
		sf::CircleShape circle(wallSprite.getTextureRect().width * 1.5f);
		circle.setRadius(circle.getRadius() * 1);
		circle.setOrigin(circle.getRadius(), circle.getRadius());
		circle.setPosition(wallSprite.getPosition());
		m_obstacles.push_back(circle);
	}
}

////////////////////////////////////////////////////////////
sf::Vector2f TankAi::seek(sf::Vector2f playerPosition) const
{

	return playerPosition - m_tankBase.getPosition();
}

////////////////////////////////////////////////////////////
sf::Vector2f TankAi::collisionAvoidance()
{
	auto headingRadians = thor::toRadian(m_rotation);
	sf::Vector2f headingVector(std::cos(headingRadians) * MAX_SEE_AHEAD, std::sin(headingRadians) * MAX_SEE_AHEAD);
	m_ahead = m_tankBase.getPosition() + headingVector;
	m_halfAhead = m_tankBase.getPosition() + (headingVector * 0.5f);
	const sf::CircleShape mostThreatening = findMostThreateningObstacle();
	sf::Vector2f avoidance(0, 0);
	if (mostThreatening.getRadius() != 0.0)
	{
		avoidance.x = m_ahead.x - mostThreatening.getPosition().x;
		avoidance.y = m_ahead.y - mostThreatening.getPosition().y;
		avoidance = thor::unitVector(avoidance);
		avoidance *= MAX_AVOID_FORCE;
	}
	else
	{
		avoidance *= 0.0f;
	}
	return avoidance;
}

////////////////////////////////////////////////////////////
const sf::CircleShape TankAi::findMostThreateningObstacle()
{
	sf::CircleShape mostThreatening;
	// The initialisation of mostThreatening is just a placeholder...
	for (sf::CircleShape circles : m_obstacles)
	{
		collision = MathUtility::lineIntersectsCircle(m_ahead, m_halfAhead, circles);
		if (collision && (distance(m_tankBase, circles) < distance(m_tankBase, mostThreatening)))
		{
			mostThreatening = circles;
		}
	}


	return mostThreatening;
}

float TankAi::distance(sf::Sprite & t_tank, sf::CircleShape & t_circ)
{
	return sqrt((t_tank.getPosition().x - t_circ.getPosition().x) * (t_tank.getPosition().x - t_circ.getPosition().x)
		+ (t_tank.getPosition().y - t_circ.getPosition().y) * (t_tank.getPosition().y - t_circ.getPosition().y));
}

bool TankAi::lineInteresectsCircle(sf::CircleShape & t_circ)
{
	float length;
	sf::Vector2f vector;
	length = sqrt((m_velocity.x * m_velocity.x) + (m_velocity.y * m_velocity.y));
	if (length != 0)
	{
		vector.x = m_velocity.x / length;
		vector.y = m_velocity.y / length;
	}
	sf::Vector2f ahead = m_tankBase.getPosition() + sf::Vector2f((vector.x * MAX_SEE_AHEAD), (vector.y * MAX_SEE_AHEAD));
	sf::Vector2f ahead2 = m_tankBase.getPosition() + sf::Vector2f((vector.x * MAX_SEE_AHEAD*0.5), (vector.y * MAX_SEE_AHEAD*0.5));

	avoidace_force = ahead - sf::Vector2f((t_circ.getPosition().x + t_circ.getRadius()),
		t_circ.getPosition().y + t_circ.getRadius());

	length = sqrt((avoidace_force.x * avoidace_force.x)
		+ (avoidace_force.y * avoidace_force.y));
	vector = avoidace_force;
	if (length != 0)
	{
		vector.x = vector.x / length;
		vector.y = vector.y / length;
	}
	avoidace_force = vector * MAX_AVOID_FORCE;

	return (sqrt(t_circ.getPosition().x - ahead.x)*(t_circ.getPosition().x - ahead.x) +
		(t_circ.getPosition().y - ahead.y)*(t_circ.getPosition().y - ahead.y) <= t_circ.getRadius()
		|| sqrt(t_circ.getPosition().x - ahead2.x)*(t_circ.getPosition().x - ahead2.x) +
		(t_circ.getPosition().y - ahead2.y)*(t_circ.getPosition().y - ahead2.y) <= t_circ.getRadius());
}

bool TankAi::collidesWithPlayer(Tank const & playerTank) const
{
	// Checks if the AI tank has collided with the player tank.
	if (CollisionDetector::collision(m_turret, playerTank.getTurret()) ||
		CollisionDetector::collision(m_tankBase, playerTank.getBase()))
	{
		return true;
	}
	return false;
}

sf::Sprite TankAi::getSprites()
{
	return m_tankBase;
}

void TankAi::takeDamge()
{
	m_health -= 1;
}

int TankAi::getHealth()
{
	return m_health;
}

void TankAi::requestFire()
{
	m_fireRequested = true;
	if (m_shootTimer == s_TIME_BETWEEN_SHOTS)
	{
		sf::Vector2f tipOfTurret(m_turret.getPosition().x + 2.0f, m_turret.getPosition().y);
		tipOfTurret.x += std::cos(MathUtility::DEG_TO_RAD  * m_turret.getRotation()) * ((m_turret.getLocalBounds().top + m_turret.getLocalBounds().height) * 1.7f);
		tipOfTurret.y += std::sin(MathUtility::DEG_TO_RAD  * m_turret.getRotation()) * ((m_turret.getLocalBounds().top + m_turret.getLocalBounds().height) * 1.7f);
		m_pool.create(m_texture, tipOfTurret.x, tipOfTurret.y, m_turret.getRotation());
	}
}

sf::Sprite TankAi::getBulletSprite(int i)
{
	return m_pool.getBulletSprite(i);
}

int TankAi::getNextBullet()
{
	return m_pool.getNextAvailible();
}

void TankAi::setNextBullet(int t_next, int i)
{
	int temp;
	temp = t_next;
	m_pool.setNextAvailible(temp, i);
}

void TankAi::heal()
{
	m_health += 3;
	if (m_health > 10)
	{
		m_health = 10;
	}
}

sf::Text TankAi::getStateText()
{
	return m_currentStateText;
}

////////////////////////////////////////////////////////////
void TankAi::initSprites()
{
	// Initialise the tank base
	m_tankBase.setTexture(m_texture);
	sf::IntRect baseRect(103, 43, 79, 43);
	m_tankBase.setTextureRect(baseRect);
	m_tankBase.setOrigin(baseRect.width / 2.0, baseRect.height / 2.0);

	// Initialise the turret
	m_turret.setTexture(m_texture);
	sf::IntRect turretRect(122, 1, 83, 31);
	m_turret.setTextureRect(turretRect);
	m_turret.setOrigin(turretRect.width / 3.0, turretRect.height / 2.0);
}


////////////////////////////////////////////////////////////
void TankAi::updateMovement(double dt)
{
	
	double speed = thor::length(m_velocity);
	sf::Vector2f newPos(m_tankBase.getPosition().x + std::cos(MathUtility::DEG_TO_RAD  * m_rotation) * speed * (dt / 1000),
		m_tankBase.getPosition().y + std::sin(MathUtility::DEG_TO_RAD  * m_rotation) * speed * (dt / 1000));
	if (!stopAndRotate)
	{
		m_tankBase.setPosition(newPos.x, newPos.y);
		m_tankBase.setRotation(m_rotation);
	}
	
	m_turret.setPosition(m_tankBase.getPosition());
	m_turret.setRotation(m_rotation);
}