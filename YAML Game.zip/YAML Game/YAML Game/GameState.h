#pragma once

enum class GameState
{
	GAME_RUNNING,
	GAME_WIN,
	GAME_LOSE
};
